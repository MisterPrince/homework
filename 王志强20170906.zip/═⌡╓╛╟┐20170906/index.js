var oUl1 = document.querySelector('.nav-ul');
myajax.get('http://h6.duchengjiu.top/shop/api_cat.php', {},function(error,responseText){
	var json = JSON.parse(responseText);
	var data = json.data;
  	for(var i = 0; i <data.length; i++){
  		var obj = data[i];
  		oUl1.innerHTML += `<li><a href="页面传值.html?cat_id=${obj.cat_id}">${obj.cat_name}</a></li>`;
  	}
});
 
var oUl2 = document.querySelector('.hot-list');
myajax.get('http://h6.duchengjiu.top/shop/api_goods.php', {}, function(error, responseText){
	var json = JSON.parse(responseText);
	var data = json.data;
	for(var i = 0; i < data.length; i++) {
		var obj = data[i];
		oUl2.innerHTML += `<li>
						<span><img src='${obj.goods_thumb}'/></span>
						<div><a href='#'>${obj.goods_name}</a><a href='#'>${obj.goods_desc}</a></div>
							</li>`
	}
})
